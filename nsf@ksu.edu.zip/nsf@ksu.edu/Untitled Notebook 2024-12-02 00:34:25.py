# Databricks notebook source
# MAGIC %run ./config/aml_config

# COMMAND ----------

display(spark.read.table(config['db_transactions']))
display(

  sql("""

  select * 

  from {0}

  where email_addr in 

  (

    select A.email_addr 

    from 

      (

        select email_addr, count(*) as cnt 

        from {0}

        group by email_addr

      ) A

    where A.cnt > 1

  )

  order by email_addr

  """.format(config['db_entities']))

)

# COMMAND ----------

from graphframes import *

identity_edges = sql('''

select entity_id as src, address as dst from {0} where address is not null

union

select entity_id as src, email_addr as dst from {0} where email_addr is not null

union

select entity_id as src, phone_number as dst from {0} where phone_number is not null

'''.format(config['db_entities']))

 

identity_nodes = sql('''

select distinct(entity_id) as id, 'Person' as type from {0}

union 

select distinct(address) as id, 'Address' as type from {0}

union 

select distinct(email_addr) as id, 'Email' as type from {0}

union 

select distinct(phone_number) as id, 'Phone' as type from {0}

'''.format(config['db_entities']))

 

aml_identity_g = GraphFrame(identity_nodes, identity_edges)

# COMMAND ----------

from pyspark.sql.functions import *

import uuid

sc.setCheckpointDir('{}/chk_{}'.format(temp_directory, uuid.uuid4().hex))

result = aml_identity_g.degrees

result = aml_identity_g.vertices.join(result,'id')

identity_nodes2notpeople = result.filter(col("type") != 'Person').filter(col("degree") != 1)

identity_nodes2people = result.filter(col("type") == 'Person')

identity_nodes2 = identity_nodes2notpeople.union(identity_nodes2people)
print(identity_nodes2.count())
display(identity_nodes2)

# COMMAND ----------

from pyspark.sql.functions import *

import uuid

sc.setCheckpointDir('{}/chk_{}'.format(temp_directory, uuid.uuid4().hex))

result = aml_identity_g.degrees

result = aml_identity_g.vertices.join(result,'id')

identity_nodes2notpeople = result.filter(col("type") != 'Person').filter(col("degree") > 2)

identity_nodes2people = result.filter(col("type") == 'Person')

identity_nodes2 = identity_nodes2notpeople.union(identity_nodes2people)
print(identity_nodes2.count())
display(identity_nodes2)

# COMMAND ----------

aml_identity_g2 = GraphFrame(identity_nodes2, identity_edges)
import uuid

sc.setCheckpointDir('{}/chk_{}'.format(temp_directory, uuid.uuid4().hex))

result = aml_identity_g2.connectedComponents()

result.select("id", "component", 'type').createOrReplaceTempView("components")

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT * FROM components

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC create or replace temp view ptntl_synthetic_ids
# MAGIC
# MAGIC as
# MAGIC
# MAGIC with dupes as
# MAGIC
# MAGIC (
# MAGIC
# MAGIC   select 
# MAGIC
# MAGIC     component, 
# MAGIC
# MAGIC     count(case when type = 'Person' then 1 end) person_ct 
# MAGIC
# MAGIC   from components
# MAGIC
# MAGIC   group by component
# MAGIC
# MAGIC   having person_ct > 1
# MAGIC
# MAGIC )
# MAGIC
# MAGIC select * from components
# MAGIC
# MAGIC where component in (select component from dupes)
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from ptntl_synthetic_ids

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC with example as (select component from ptntl_synthetic_ids WHERE id = "4960")
# MAGIC
# MAGIC select * from ptntl_synthetic_ids WHERE component in (select * from example)

# COMMAND ----------

suspicious_component_id = (

  spark

    .sql("select id as id0, component, type from ptntl_synthetic_ids")

    .filter(col('type') == 'Person')

    .drop('type')

)

 

ids = suspicious_component_id.join(spark.table("ptntl_synthetic_ids"), ['component']).filter(col('id0') != col('id'))

ids.createOrReplaceTempView("sus_ids")

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from sus_ids WHERE component = "68719476738"

# COMMAND ----------

# MAGIC %sql 
# MAGIC
# MAGIC CREATE OR REPLACE table entity_synth_scores as (
# MAGIC
# MAGIC   select
# MAGIC
# MAGIC     component,
# MAGIC
# MAGIC     id0,
# MAGIC
# MAGIC     count(*) as synth_score
# MAGIC
# MAGIC   from
# MAGIC
# MAGIC     sus_ids
# MAGIC
# MAGIC   GROUP BY
# MAGIC
# MAGIC     component,
# MAGIC
# MAGIC     id0
# MAGIC
# MAGIC )
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC  
# MAGIC
# MAGIC SELECT * from entity_synth_scores

# COMMAND ----------

entity_synth_scores = sql("""SELECT * from entity_synth_scores""")

entity_synth_scores.write.format("delta").mode('overwrite').option("overwriteSchema", "true").saveAsTable(config['db_synth_scores'])



# COMMAND ----------

display(spark.read.table(config['db_transactions']))

# COMMAND ----------

display(

  sql("""

  select * 

  from {0}

  where email_addr in 

  (

    select A.email_addr 

    from 

      (

        select email_addr, count(*) as cnt 

        from {0}

        group by email_addr

      ) A

    where A.cnt > 1

  )

  order by email_addr

  """.format(config['db_entities']))

)

# COMMAND ----------

from graphframes import *
identity_edges = sql('''

select entity_id as src, address as dst from {0} where address is not null

union

select entity_id as src, email_addr as dst from {0} where email_addr is not null

union

select entity_id as src, phone_number as dst from {0} where phone_number is not null

'''.format(config['db_entities']))

 

identity_nodes = sql('''

select distinct(entity_id) as id, 'Person' as type from {0}

union 

select distinct(address) as id, 'Address' as type from {0}

union 

select distinct(email_addr) as id, 'Email' as type from {0}

union 

select distinct(phone_number) as id, 'Phone' as type from {0}

'''.format(config['db_entities']))

 

aml_identity_g = GraphFrame(identity_nodes, identity_edges)

# COMMAND ----------

entity_edges = spark.sql(

"""

select 

  originator_id as src, 

  beneficiary_id as dst, 

  txn_amount, txn_id as id 

from {0}

""".format(config['db_transactions'])

)

 

entity_nodes = spark.sql(

"""

select 

  distinct(A.id), 

  'entity' as type 

from

  (

    select 

      distinct(originator_id) as id 

    from {0}

    union 

    select 

      distinct(beneficiary_id) as id 

    from {0}

  ) A

""".format(config['db_transactions'])

)

 

aml_entity_g = GraphFrame(entity_nodes, entity_edges)

entity_edges.createOrReplaceTempView("entity_edges")

entity_nodes.createOrReplaceTempView("entity_nodes")

# COMMAND ----------

motif = "(a)-[e1]->(b); (b)-[e2]->(c); (d)-[e3]->(f); (f)-[e5]->(c); (c)-[e6]->(g)"

struct_scn_1 = aml_entity_g.find(motif)

 

display(struct_scn_1)

# COMMAND ----------

joined_graphs = (

  struct_scn_1.alias("graph1")

  .join(struct_scn_1.alias("graph2"), col("graph1.g.id") == col("graph2.g.id"))

  .filter(col("graph1.e6.txn_amount") + col("graph2.e6.txn_amount") > 10000)

)

 

joined_graphs.selectExpr("graph1.*").write.option("overwriteSchema", "true").mode('overwrite').saveAsTable(config['db_structuring'])




# COMMAND ----------



levels = sql(

    """

    SELECT * FROM (SELECT DISTINCT entity0.name l0_name, entity1.name l1_name, entity2.name l2_name, entity3.name l3_name

    from {0} graph

    join {1} entity0

    on graph.a.id = entity0.entity_id

    join {1} entity1

    on graph.b.id = entity1.entity_id

    join {1} entity2 

    on graph.c.id = entity2.entity_id

    join {1} entity3

    on graph.g.id = entity3.entity_id

    where entity3.entity_type = 'Company') abcg

    UNION ALL

    SELECT * FROM (SELECT DISTINCT entity0.name l0_name, entity1.name l1_name, entity2.name l2_name, entity3.name l3_name

    from {0} graph

    join {1} entity0

    on graph.d.id = entity0.entity_id

    join {1} entity1

    on graph.f.id = entity1.entity_id

    join {1} entity2 

    on graph.c.id = entity2.entity_id

    join {1} entity3

    on graph.g.id = entity3.entity_id

    where entity3.entity_type = 'Company') dfcg

    """.format(config['db_structuring'], config['db_entities'])

  )

levels.write.option("overwriteSchema", "true").mode('overwrite').saveAsTable(config['db_structuring_levels'])

# COMMAND ----------

display(levels)


# COMMAND ----------

motif = "(a)-[e1]->(b); (b)-[e2]->(c); (c)-[e3]->(d); (d)-[e4]->(a)"

round_trip = aml_entity_g.find(motif)

round_trip.write.mode('overwrite').saveAsTable(config['db_roundtrips'])

display(round_trip)

# COMMAND ----------

display(

  sql(

    """

    select

      ents0.name original_entity,

      ents1.name intermediate_entity_1,

      ents2.name intermediate_entity_2,

      ents3.name intermediate_entity_3,

      int(rt.e1.txn_amount) + int(rt.e2.txn_amount) + int(rt.e3.txn_amount) + int(rt.e4.txn_amount) agg_txn_amount

    from

      {0} rt

      join {1} ents0 on rt.a.id = ents0.entity_id

      join {1} ents1 on rt.b.id = ents1.entity_id

      join {1} ents2 on rt.c.id = ents2.entity_id

      join {1} ents3 on rt.d.id = ents3.entity_id

    """.format(config['db_roundtrips'], config['db_entities'])

  )

)

# COMMAND ----------

entity_edges = spark.sql("""

select 

  originator_id as src, 

  beneficiary_id as dst, 

  txn_amount, 

  txn_id as id 

from {}

""".format(config['db_transactions']))

 

entity_nodes = spark.sql("""

select 

  distinct(A.id), risk 

from

  (

    select 

      distinct(entity_id) as id, 

      risk_score risk 

    from {}

  ) A

""".format(config['db_entities']))

 

entity_edges.createOrReplaceTempView("entity_edges")

entity_nodes.createOrReplaceTempView("entity_nodes")

aml_entity_g = GraphFrame(entity_nodes, entity_edges)
from graphframes import GraphFrame

from pyspark.sql.functions import coalesce, col, lit, sum, when, greatest

from graphframes.lib import Pregel

 

ranks = aml_entity_g.pregel.setMaxIter(3) .withVertexColumn("risk_score", col("risk"), coalesce(Pregel.msg()+ col("risk"), col("risk_score"))) .sendMsgToDst(Pregel.src("risk_score")/2 ).aggMsgs(sum(Pregel.msg())).run()

 

ranks.write.mode('overwrite').saveAsTable(config['db_risk_propagation'])
display(

  sql(

    """

    select

      a.id,

      a.risk_score,

      a.risk original_risk_score,

      b.name

    from

      {0} a

      join {1} b on a.id = b.entity_id

    where

      id >= 10000001

    """.format(config['db_risk_propagation'], config['db_entities'])

  )

)

# COMMAND ----------

from pyspark.sql.functions import * 

 

addresses = (

  spark

    .table(config['db_entities'])

    .filter(col("address").isNotNull())

    .withColumn("address", translate(translate(col("address"), ',', ''), ' ', '+'))

    .select('address')

    .toPandas()

)

 

addresses.head(5)



# COMMAND ----------

goog_api_key = dbutils.secrets.get(scope="solution-accelerator-cicd", key="google-api")     

# COMMAND ----------

raw_records = spark.read.table(config['db_dedupe'])

display(raw_records)

# COMMAND ----------

settings = {

    "link_type": "dedupe_only",

    "blocking_rules": [

        "l.amount = r.amount",

    ],

    "comparison_columns": [

        {

            "col_name": "org_name",

            "term_frequency_adjustments": True},

        {

            "col_name": "address",

            "term_frequency_adjustments": True

        },

        {

            "col_name": "country"

        },

              {

            "col_name": "amount"

        }

    ]

}

 

from splink import Splink

linker = Splink(settings, raw_records, spark)

raw_records_entities = linker.get_scored_comparisons()

display(raw_records_entities.take(1))



# COMMAND ----------

raw_records_entities.write.mode("overwrite").format("delta").saveAsTable(config['db_dedupe_records'])
model = linker.model

model.probability_distribution_chart()

model.bayes_factor_chart()

model.all_charts_write_html_file(f"{temp_directory}/splink_charts.html", overwrite=True)
html_file_content = open(f"{temp_directory}/splink_charts.html", 'r').read()

displayHTML(html_file_content)

# COMMAND ----------

from splink.intuition import intuition_report

row_dict = raw_records_entities.toPandas().sample(1).to_dict(orient="records")[0]

print(intuition_report(row_dict, model))

# COMMAND ----------

df2 = spark.table(config['db_transactions'])

df2 = df2.withColumnRenamed("txn_id", "unique_id")

display(df2)

# COMMAND ----------

settings = {

    "link_type": "dedupe_only",

    "blocking_rules": [

        "l.txn_amount = r.txn_amount",

    ],

    "comparison_columns": [

        

        {

            "col_name": "rptd_originator_address",

        }, 

        { 

            "col_name": "rptd_originator_name",

        }

    ]

}

 

from splink import Splink

linker = Splink(settings, df2, spark)

df2_e = linker.get_scored_comparisons()
from pyspark.sql.functions import * 

display(df2_e.filter( (col("rptd_originator_address_l") != '')).filter((col("rptd_originator_address_r") != '')))